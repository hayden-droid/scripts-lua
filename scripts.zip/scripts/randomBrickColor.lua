local pop = game.Workspace.Pop
local pop2 = true
while pop2 true do
wait(.5)
pop.BrickColor = "Really Red"
wait(.5)
pop.BrickColor = "Green"
wait(.5)
pop.BrickColor = "Blue"
wait(.5)
end

