-- insert a part and name it Part

-- insert another part and name it Part2

-- insert anmother part and name Maker

-- THIS SCRIPT GOES IN Workspace

local part = game.Workspace.Part

local part2 = game.Workspace.Part2

for i = 0,1,.01 do

wait()

part.CFrame = part.CFrame:Lerp(part2.CFrame, i)

end


--or

--[[

local part = game.Workspace.Part

local part2 = game.Workspace.Part2

part.CFrame = game.CFrame:Lerp(part2.CFrame, .5)

for i = 0,1,.01 do

wait()

end
]]


-- another

--[[
local part = game.Workspace.Part


for i = 0,1,.01 do

wait()

part.CFrame = part.CFrame:Lerp(CFrame.new(x,y,z) * CFrame.Angles(math.rad(x),math.rad(y),math.rad(z)), i)---change the (CFrame.new(x,y,z) * CFrame.Angles(math.rad(x),math.rad(y),math.rad(z)),i) chnage the x,y,z on first opn to the position of the pl;ace you want it to go and the second part is the rotation

end



]]
